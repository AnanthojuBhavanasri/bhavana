package com.datasouk.mif.servicenow.models;

import java.util.List;

public class ServicenowFields {
	String dataUsageId;
	
	String schemaName;
	String requesterNames;
	String requesterMailID;
	String dataUsageURL;
	String impactValue;
	String urgencyValue;
	String callerName;
	String description;
	String dataElement;
	String priority;
	String deliveryPreferences;
	String deliveryPlatform;
	String dataRefreshFrequency;
	  private List<String> orderUrls;
	public String getDataUsageId() {
		return dataUsageId;
	}
	public void setDataUsageId(String dataUsageId) {
		this.dataUsageId = dataUsageId;
	}
	public String getSchemaName() {
		return schemaName;
	}
	public void setSchemaName(String schemaName) {
		this.schemaName = schemaName;
	}
	public String getRequesterNames() {
		return requesterNames;
	}
	public void setRequesterNames(String requesterNames) {
		this.requesterNames = requesterNames;
	}
	public String getRequesterMailID() {
		return requesterMailID;
	}
	public void setRequesterMailID(String requesterMailID) {
		this.requesterMailID = requesterMailID;
	}
	public String getDataUsageURL() {
		return dataUsageURL;
	}
	public void setDataUsageURL(String dataUsageURL) {
		this.dataUsageURL = dataUsageURL;
	}
	public String getImpactValue() {
		return impactValue;
	}
	public void setImpactValue(String impactValue) {
		this.impactValue = impactValue;
	}
	public String getUrgencyValue() {
		return urgencyValue;
	}
	public void setUrgencyValue(String urgencyValue) {
		this.urgencyValue = urgencyValue;
	}
	public String getCallerName() {
		return callerName;
	}
	public void setCallerName(String callerName) {
		this.callerName = callerName;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getDataElement() {
		return dataElement;
	}
	public void setDataElement(String dataElement) {
		this.dataElement = dataElement;
	}
	public String getPriority() {
		return priority;
	}
	public void setPriority(String priority) {
		this.priority = priority;
	}
	public String getDeliveryPreferences() {
		return deliveryPreferences;
	}
	public void setDeliveryPreferences(String deliveryPreferences) {
		this.deliveryPreferences = deliveryPreferences;
	}
	public String getDeliveryPlatform() {
		return deliveryPlatform;
	}
	public void setDeliveryPlatform(String deliveryPlatform) {
		this.deliveryPlatform = deliveryPlatform;
	}
	public String getDataRefreshFrequency() {
		return dataRefreshFrequency;
	}
	public void setDataRefreshFrequency(String dataRefreshFrequency) {
		this.dataRefreshFrequency = dataRefreshFrequency;
	}
	public List<String> getOrderUrls() {
		return orderUrls;
	}
	public void setOrderUrls(List<String> orderUrls) {
		this.orderUrls = orderUrls;
	}
	
	
	
	

}
