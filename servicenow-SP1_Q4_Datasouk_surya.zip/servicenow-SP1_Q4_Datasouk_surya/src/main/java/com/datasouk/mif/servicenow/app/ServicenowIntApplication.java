package com.datasouk.mif.servicenow.app;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

@SpringBootApplication
@ComponentScan({ "com.datasouk.mif.servicenow.*", "com.datasouk.mif.arango.*" })
public class ServicenowIntApplication {

	public static void main(String[] args) {
		SpringApplication.run(ServicenowIntApplication.class, args);
	}

}
