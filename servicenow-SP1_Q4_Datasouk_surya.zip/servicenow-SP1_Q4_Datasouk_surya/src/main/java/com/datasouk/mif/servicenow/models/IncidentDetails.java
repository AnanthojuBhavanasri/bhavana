package com.datasouk.mif.servicenow.models;

public class IncidentDetails {
	
	int state;
	String incident;
	String usageid;
	int priority;
	public int getPriority() {
		return priority;
	}
	public void setPriority(int priority) {
		this.priority = priority;
	}
	public int getState() {
		return state;
	}
	public void setState(int state) {
		this.state = state;
	}
	public String getIncident() {
		return incident;
	}
	public void setIncident(String incident) {
		this.incident = incident;
	}
	public String getUsageid() {
		return usageid;
	}
	public void setUsageid(String usageid) {
		this.usageid = usageid;
	}
	

}
