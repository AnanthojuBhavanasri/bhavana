package com.datasouk.mif.arango.restclient;

import java.util.Collection;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.arangodb.ArangoCollection;
import com.arangodb.ArangoDB;
import com.arangodb.ArangoDatabase;
import com.datasouk.mif.servicenow.properties.DatasoukProperties;
@Service
public class ArangoRestClient {
	Logger log = LoggerFactory.getLogger(ArangoRestClient.class);

	private final DatasoukProperties datasoukProperties;

	@Autowired
	public ArangoRestClient(DatasoukProperties datasoukProperties) {
		this.datasoukProperties = datasoukProperties;
	}
	
	public ArangoDB getArangoConnection() {

		ArangoDB arangoDB = null;
		try {
			arangoDB = new ArangoDB.Builder().user(datasoukProperties.getUser()).password(datasoukProperties.getPassword()).host(datasoukProperties.getHost(),datasoukProperties.getPort()).build();
		} catch (Exception e) {
			log.error("Exception while connecting to Arango DB: " + e.getMessage().toString());
		}

		return arangoDB;
	}

	public ArangoDatabase getArangoDBConnection(ArangoDB arango, String dbName) {

		ArangoDatabase arangodb = null;

		Collection<String> arangodbs = arango.getDatabases();

		if (arangodbs.contains(dbName)) {
			log.info("database is exited with name :{}",dbName);
			arangodb = arango.db(dbName);
			log.info("database is exited with name :{}",arangodb);

		} else {

			Boolean createdb = arango.createDatabase(dbName);
			if (createdb) {
				arangodb = arango.db(dbName);

			} else {
				log.error("Exception while creating database: " + dbName);
			}
		}
		return arangodb;
	}

	public ArangoCollection getArangoCollection(ArangoDatabase arangodb, String collectionName) {

		ArangoCollection arangoCollection = null;

		boolean createCollection = true;

		try {

			arangodb.createCollection(collectionName);
			
			arangoCollection = arangodb.collection(collectionName);
			

		} catch (Exception e) {
			log.info("Collection already exists with the name: " + collectionName);
			createCollection = false;
		}
		System.out.println("collectionFound--->" + createCollection);
		if (!createCollection) {
			System.out.println("collectionFound--->" + createCollection);
			arangoCollection = arangodb.collection(collectionName);
		}
		return arangoCollection;

	}
	
	
	


}
