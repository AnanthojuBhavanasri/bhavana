package com.datasouk.mif.servicenow.service;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.datasouk.mif.servicenow.restclient.ServiceNowRestClient;
import com.arangodb.ArangoCollection;
import com.arangodb.ArangoCursor;
import com.arangodb.ArangoDB;
import com.arangodb.ArangoDatabase;
import com.datasouk.mif.arango.restclient.ArangoRestClient;
import com.datasouk.mif.servicenow.constants.ServiceNowConstants;
import com.datasouk.mif.servicenow.properties.DatasoukProperties;
import com.datasouk.mif.servicenow.properties.ServicenowProperties;
import com.datasouk.mif.servicenow.models.ServicenowFields;

@Service
public class ServicenowService {
	Logger log = LoggerFactory.getLogger(ServicenowService.class);
	private ServiceNowRestClient serviceNowRestClient;
	private ServicenowProperties servicenowProperties;
	private ArangoRestClient arangoRestClient;
	private DatasoukProperties dataSoukProperties;

	@Autowired
	public ServicenowService(ServicenowProperties servicenowProperties, ServiceNowRestClient serviceNowRestClient,
			ArangoRestClient arangoRestClient, DatasoukProperties dataSoukProperties) {
		this.servicenowProperties = servicenowProperties;
		this.serviceNowRestClient = serviceNowRestClient;
		this.arangoRestClient = arangoRestClient;
		this.dataSoukProperties = dataSoukProperties;
	}

	/*
	 * Creating Incident in Servicenow
	 */
	public String createIncident(ServicenowFields servicenowFields) {

		JSONObject sendJson = new JSONObject();
		final String[] DataUsage = servicenowFields.getDataUsageId().split("/");
		final String collectionID = DataUsage[1];
		final String collection = DataUsage[0];

		int impact = 0;
		int urgency = 0;

		sendJson.put("u_orderurls", servicenowFields.getOrderUrls());
		sendJson.put("caller_id", servicenowFields.getCallerName());
		//sendJson.put("state", servicenowFields.);

		sendJson.put("short_description", servicenowFields.getDataUsageId());
//		sendJson.put("caller_id", servicenowFields.getCallerName());
//		sendJson.put("caller", servicenowFields.getCallerName());
		Map<String, String> description = new HashMap<>();
		description.put("Schema Name", servicenowFields.getSchemaName());
		description.put("DataUsage_Url", servicenowFields.getDataUsageURL());
		description.put("Requester Name", servicenowFields.getRequesterNames());
		description.put("Requester_Mail_Id", servicenowFields.getRequesterMailID());
		description.put("Data Element", servicenowFields.getDataElement());
		description.put("caller_id", servicenowFields.getCallerName());
		description.put("Delivery platform", servicenowFields.getDeliveryPlatform());
		description.put("DataRefreshFrequency", servicenowFields.getDataRefreshFrequency());
		description.put("Delivery Preferences", servicenowFields.getDeliveryPreferences());

		sendJson.put("description", description);
		sendJson.put("urgency", servicenowFields.getUrgencyValue());
		sendJson.put("impact", servicenowFields.getImpactValue());
		sendJson.put("caller_id", servicenowFields.getCallerName());
		sendJson.put("priority", servicenowFields.getPriority());
		sendJson.put("service_offering", servicenowFields.getDeliveryPlatform());
		sendJson.put("cmdb_ci", servicenowFields.getDeliveryPreferences());

		String priority = servicenowFields.getPriority();

		if (priority.equalsIgnoreCase("Critical")) {
			urgency = 1;
			impact = 1;
		} else if (priority.equalsIgnoreCase("High")) {
			urgency = 2;
			impact = 1;
		} else if (priority.equalsIgnoreCase("Moderate")) {
			urgency = 2;
			impact = 2;
		} else if (priority.equalsIgnoreCase("Low")) {
			urgency = 2;
			impact = 3;
		} else if (priority.equalsIgnoreCase("Planning")) {
			urgency = 3;
			impact = 3;

		}

		sendJson.put("urgency", urgency);
		sendJson.put("impact", impact);

		String postIncidentUrl = servicenowProperties.getUrl() + "/api/now/table/incident";
		ResponseEntity<String> responses = serviceNowRestClient.sendData(postIncidentUrl, sendJson.toString());

		String responseBody = responses.getBody();
		log.info("response:{}", responseBody);

		JSONObject responseJsonBody;
		String dataUsageAssetId = servicenowFields.getDataUsageId();
		String incidentNumber = "";
		int incidentState = 1;
		try {
			responseJsonBody = new JSONObject(responseBody);

			// Asset Id
			dataUsageAssetId = servicenowFields.getDataUsageId();

			// Attribute Values
			incidentState = responseJsonBody.getJSONObject(ServiceNowConstants.RESULT)
					.getInt(ServiceNowConstants.INCIDENTSTATE);
			incidentNumber = responseJsonBody.getJSONObject(ServiceNowConstants.RESULT)
					.getString(ServiceNowConstants.INCIDENTNUMBER);

		} catch (final JSONException e) {
			log.error(String.format("JSONException Caught %s", e.toString()));
		}

		log.info("Incident Created with Number : {}", incidentNumber);

		String incidentStateValue = "";
		switch (incidentState) {
		case 1:
			incidentStateValue = ServiceNowConstants.NEW;
			break;
		// IN PROGRESS
		case 2:
			incidentStateValue = ServiceNowConstants.INPROGRESS;
			break;
		// ON HOLD
		case 3:
			incidentStateValue = ServiceNowConstants.ONHOLD;
			break;
		// RESOLVED
		case 6:
			incidentStateValue = ServiceNowConstants.RESOLVED;
			break;
		// CLOSED
		case 7:
			incidentStateValue = ServiceNowConstants.CLOSED;
			break;
		// CANCELED
		case 8:
			incidentStateValue = ServiceNowConstants.CANCELLED;
			break;
		default:
			log.info(incidentStateValue);
		}

		List<Object> response = null;
		ArangoDB arangoConn = arangoRestClient.getArangoConnection();
		if (arangoConn != null) {
			ArangoDatabase arangodb = arangoRestClient.getArangoDBConnection(arangoConn,
					dataSoukProperties.getDatabase());

			if (arangodb != null) {
				ArangoCollection arangoCollection = arangoRestClient.getArangoCollection(arangodb, collection);

				String queryToBeExecuted = "for doc in " + collection + "\r\n"

						+ "filter doc._key == " + "'" + (collectionID) + "'" + "\r\n"
						+ "update doc With {IncidentNumber:" + "'" + (incidentNumber) + "'" + ",IncidentState:" + "'"
						+ (incidentStateValue) + "'" + "} in dataUsageCollection";
				System.out.println("queryToBeExecuted----->" + queryToBeExecuted);
				ArangoCursor<Object> cursor = null;
				try {

					cursor = arangodb.query(queryToBeExecuted, Object.class);
					response = cursor.asListRemaining();

				} catch (Exception e) {
					log.error("Exception while executing  Query: " + e.getMessage().toString());
				}
			}
		}

		return "successfully created incident and stored Incidentstate and IncidentNo in DataUsage collection";
	}

	public String uploadIncidentDetails(String dataUsageAssetId, String incidentNumber, int incidentState, int priority,
			String condition) throws IOException {
		String incidentStateValue = "";

		final String[] DataUsage = dataUsageAssetId.split("/");
		final String collectionID = DataUsage[1];
		final String collection = DataUsage[0];
		log.info("collectionID:{}", collectionID);
		log.info("collection:{}", collection);

		switch (incidentState) {
		case 1:
			incidentStateValue = ServiceNowConstants.NEW;
			break;
		case 2:
			incidentStateValue = ServiceNowConstants.INPROGRESS;
			break;
		case 3:
			incidentStateValue = ServiceNowConstants.ONHOLD;
			break;
		case 6:
			incidentStateValue = ServiceNowConstants.RESOLVED;
			break;
		case 7:
			incidentStateValue = ServiceNowConstants.CLOSED;
			break;
		case 8:
			incidentStateValue = ServiceNowConstants.CANCELLED;
			break;
		default:
			log.info(incidentStateValue);

		}
		String priroityValue = "";
		switch (priority) {
		case 1:
			priroityValue = "Critical";
			break;
		// IN PROGRESS
		case 2:
			priroityValue = "High";
			break;
		// ON HOLD
		case 3:
			priroityValue = "Moderate";
			break;
		// RESOLVED
		case 4:
			priroityValue = "Low";
			break;
		// CLOSED
		case 5:
			priroityValue = "Planning";
			break;
		}
		log.info(priroityValue);

		List<Object> response = null;
		ArangoDB arangoConn = arangoRestClient.getArangoConnection();
		if (arangoConn != null) {
			ArangoDatabase arangodb = arangoRestClient.getArangoDBConnection(arangoConn,
					dataSoukProperties.getDatabase());

			if (arangodb != null) {
				ArangoCollection arangoCollection = arangoRestClient.getArangoCollection(arangodb, collection);

				String queryToBeExecuted = "for doc in " + collection + "\r\n"

						+ "filter doc._key == '" + collectionID + "'\r\n" + "update doc With {priority:" + "'"
						+ (priroityValue) + "'" + ",IncidentState:" + "'" + (incidentStateValue) + "'"
						+ "} in dataUsageCollection";
				System.out.println("queryToBeExecuted----->" + queryToBeExecuted);
				ArangoCursor<Object> cursor = null;
				try {

					cursor = arangodb.query(queryToBeExecuted, Object.class);
					response = cursor.asListRemaining();

				} catch (Exception e) {
					log.error("Exception while executing  Query: " + e.getMessage().toString());
				}
			}

		}
		return "successfully updated to arrango db";
	}
}
