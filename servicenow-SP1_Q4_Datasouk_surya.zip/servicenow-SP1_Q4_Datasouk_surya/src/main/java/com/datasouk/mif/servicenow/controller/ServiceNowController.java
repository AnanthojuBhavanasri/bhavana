package com.datasouk.mif.servicenow.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.datasouk.mif.servicenow.controller.ServiceNowController;
import com.datasouk.mif.servicenow.service.ServicenowService;
import com.datasouk.mif.servicenow.constants.ServiceNowConstants;
import com.datasouk.mif.servicenow.models.IncidentDetails;
import com.datasouk.mif.servicenow.models.ServicenowFields;
@RestController
public class ServiceNowController {
	
	Logger log = LoggerFactory.getLogger(ServiceNowController.class);

	private  ServicenowService serviceNowService;
	@Autowired
	public ServiceNowController(ServicenowService serviceNowService) {
		this.serviceNowService = serviceNowService;
	}
	
	@PostMapping(value = "/createIncident")
	public String createIncident(@RequestBody ServicenowFields dcsdetails) {
	
		log.info("orderurls:{}",dcsdetails.getOrderUrls());
		log.info("CallerName:{}",dcsdetails.getCallerName());
		//log.info("CallerName:{}",dcsdetails.getCallerName());
		String response = null;
		response=serviceNowService.createIncident(dcsdetails);
		
		log.info("Returning response:{}",response);
		
		return response;
	}
	@PostMapping(value = "/sendIncidentDetails")
	public String sendIncidentDetails(@RequestBody IncidentDetails snowDetails) {
				
		String response = null;
		try {
			log.info("Usageid:{}",snowDetails.getUsageid());
			log.info("state:{}",snowDetails.getState());
			log.info("Pri:{}",snowDetails.getPriority());
			
			
			response = serviceNowService.uploadIncidentDetails(snowDetails.getUsageid(), snowDetails.getIncident(),
					snowDetails.getState(), snowDetails.getPriority(),ServiceNowConstants.INCIDENTUPDATE);
		
		} catch (Exception e) {
			log.error("Exception due to {}", e.toString());
		}
		return response;
	}
	
	
	
	}

	
	
	

